//
// Created by Bruno Gómez García on 19/6/23.
//

#ifndef ROL_TYPEHEROES_H
#define ROL_TYPEHEROES_H


namespace  Heroes {
    enum class TypeHeroes {
        GUERRERO,
        MAGO,
        HECHICERO,
        NIGROMANTE
    };
}

#endif //ROL_TYPEHEROES_H
