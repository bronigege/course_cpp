//
// Created by Bruno Gómez García on 19/6/23.
//

#ifndef ROL_TYPEENEMIES_H
#define ROL_TYPEENEMIES_H

namespace Enemies {
    enum class TypeEnemies {
        TROLL,
        DRAGON,
        GUERRERO
    };
}

#endif //ROL_TYPEENEMIES_H
