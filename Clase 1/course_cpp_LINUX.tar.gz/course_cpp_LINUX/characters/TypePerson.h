//
// Created by Bruno Gómez García on 19/6/23.
//

#ifndef ROL_TYPEPERSON_H
#define ROL_TYPEPERSON_H

enum class TypePerson {
    GUERRERO,
    MAGO,
    HECHICERO,
    NIGROMANTE
};

#endif //ROL_TYPEPERSON_H
